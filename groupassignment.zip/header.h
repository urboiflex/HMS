#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define MAXATTEMPT 3
#define BillPerAppointment 100
#define maxlinelength 100
#define InsuranceDiscount 80

struct Schedule {
    char doctor_name[100];
    char day[20];
    char date[11];
    char time_slot[20];
};

struct Appointment {
    char doctor_name[100];
    char patient_name[100];
    char date[11];
    char time_slot[20];
};

struct Doctor {
    char name[100];
    char id[20];
};

struct HealthRecord {
    char medicalHistoryPatientFirstName[100];
    char medicalHistoryPatientLastName[100];
    char gender[100];
    int birthday;
    int birthmonth;
    int birthyear;
    char medicalHistory[1000];
    char allergies[1000];
    char medication[1000];
    char pastProcedure[1000];
    char diagnosticReports[1000];
};

struct Supplies {
    char name[50];
    int quantity;
};

struct DateCount {
    char date[11];
    int count;
};

void clearInputBuffer();
void HospitalAdministratorMenu();
void PatientMenu(const char *storedUser);
void PatientAppointmentMenu(const char *patient_name);
void makeAppointment(const char *patient_name);
void viewAppointment(const char *patient_name);
void rescheduleAppointment(const char *patient_name);
void cancelAppointment(const char *patient_name);
int loadSchedule(struct Schedule schedule[], const char *doctor_name);
void readAppointmentTrends(const char *filename);
void BillingManagement();
void DoctorMenu(char storedUser[]);
void NurseMenu();
void RegisterNewUsers();
void addSupplies(struct Supplies *supplies, int *numSupplies);
void displaySupplies(struct Supplies *supplies, int numSupplies);
void saveToFile(struct Supplies *supplies, int numSupplies);
void InventoryManagement();
void ManagingInventory();
void DoctorMenuManage(char doctor_name[]);
void DoctorMakeSchedules(struct Schedule schedules[], int *numSchedules, const char *doctor_name);
void DoctorViewSchedules(const char *doctor_name);
void DoctorSaveSchedulesToFile(struct Schedule schedules[], int numSchedules, const char *doctor_name);
void DoctorRemoveSchedules(struct Schedule schedules[], int *numSchedules, const char *doctor_name);
void DoctorLoadSchedulesFromFile(struct Schedule schedules[], int *numSchedules, const char *doctor_name);
void loadDoctors(struct Doctor doctors[], int *numDoctors, const char *filename);
void displayDoctors(struct Doctor doctors[], int numDoctors);
void viewSchedules(const char *doctor_name);
void DoctorReportingAnalytics ();
void DoctorViewAllPatients();
void DoctorSearchPatients();
void NurseReportingAnalytics();
void NurseViewAllPatients();
void NurseSearchPatients();
void SearchPatientsEHR();
int loadFromFile(struct Supplies *supplies);
int electronichealthrecords();
int chooseDoctor(struct Doctor doctors[], int numDoctors);
int Doctorlogin();
int HospitalAdministratorCheck();
int PatientCheck();
int NurseCheck();
int patientregister();
int doctorregister();
int nurseregister();



int leapyear(int year) {
    return ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0));
}

int validdate(int day, int month, int year) {
    if (year < 1900 || year > 9999) return 0;
    if (month < 1 || month > 12) return 0;

    int maxDays = 31;
    if (month == 4 || month == 6 || month == 9 || month == 11) maxDays = 30;
    else if (month == 2) {
        if (leapyear(year)) maxDays = 29;
        else maxDays = 28;
    }

    return (day >= 1 && day <= maxDays);
}

void HospitalAdministratorMenu() {
    int choice;

    do {
        printf("-------------------------------------\n");
        printf("|   Hospital Administrator Menu:    |\n");
        printf("-------------------------------------\n");
        printf("|       1. Register New User        |\n");
        printf("|       2. Managing Inventory       |\n");
        printf("|       3. Appointment Trends       |\n");
        printf("|       4. Exit                     |\n");
        printf("-------------------------------------\n");
        printf("Enter your choice: ");

        if (scanf("%d", &choice) != 1) {
            printf("Invalid input. Please enter a number.\n");
            clearInputBuffer();
            continue;
        }

        if (choice < 1 || choice > 4) {
            printf("Invalid Input. Please try again!\n");
            continue;
        }

        switch (choice) {
            case 1:
                printf("Directing to Register New User...\n");
                RegisterNewUsers();
                break;
            case 2:
                printf("Directing to Managing Inventory...\n");
                ManagingInventory();
                break;
            case 3:
                printf("Directing to Appointment Trends...\n");
                readAppointmentTrends("patient_appointments.txt");
                break;
            case 4:
                printf("Exiting Program...\n");
                return;
            default:
                printf("Invalid choice. Try again.\n");
        }
    } while (choice != 4);
}

void addSupplies(struct Supplies *supplies, int *numSupplies) {
    printf("Enter supply name (use _ for spaces): ");
    scanf("%s", supplies[*numSupplies].name);

    printf("Enter available Quantity: ");
    scanf("%d", &supplies[*numSupplies].quantity);
    getchar();
    (*numSupplies)++;
    printf("Supply added successfully !\n");
}

void displaySupplies(struct Supplies *supplies, int numSupplies) {
    if (numSupplies == 0) {
        printf("No supplies found.\n");
    } else {
        printf("\nSupplies in the inventory:\n");
        printf("%-20s %s\n", "Name", "Quantity");

        for (int i = 0; i < numSupplies; i++) {
            printf("%-20s %d\n", supplies[i].name, supplies[i].quantity);
        }
        printf("\n");
    }
}

void saveToFile(struct Supplies *supplies, int numSupplies) {
    FILE *file = fopen("Hospital_Inventory.txt", "w");
    if (file == NULL) {
        printf("Error opening file for writing.\n");
        return;
    }

    for (int i = 0; i < numSupplies; i++) {
        fprintf(file, "%s %d\n", supplies[i].name, supplies[i].quantity);
    }
    fclose(file);
    printf("Supplies saved to file successfully!\n");
}

int loadFromFile(struct Supplies *supplies) {
    FILE *file = fopen("Hospital_Inventory.txt", "r");
    if (file == NULL) {
        return 0;
    }

    int numSupplies = 0;
    while (fscanf(file, "%s %d", supplies[numSupplies].name, &supplies[numSupplies].quantity) == 2) {
        numSupplies++;
    }

    fclose(file);
    return numSupplies;
}

void InventoryManagement() {
    struct Supplies supplies[10000];
    int numSupplies = loadFromFile(supplies);
    int choice;

    printf("Directing to Managing Inventory...\n");

    do {
        printf("----------------------------\n");
        printf("|       1. Add Supplies     |\n");
        printf("|       2. Display Supplies |\n");
        printf("|       3. Exit             |\n");
        printf("----------------------------\n");
        printf("Enter your choice: ");

        if (scanf("%d", &choice) != 1) {
            printf("Invalid input. Please enter a number.\n");
            clearInputBuffer();
            continue;
        }
        clearInputBuffer();

        if (choice < 1 || choice > 3) {
            printf("Invalid choice. Please try again!\n");
            continue;
        }

        switch (choice) {
            case 1:
                addSupplies(supplies, &numSupplies);
                break;
            case 2:
                displaySupplies(supplies, numSupplies);
                break;
            case 3:
                saveToFile(supplies, numSupplies);
                printf("Data saved. Exiting inventory management.\n");
                break;
            default:
                printf("Invalid choice. Try again.\n");
        }
    } while (choice != 3);
}

void ManagingInventory() {
    struct Supplies supplies[10000];
    int numSupplies = loadFromFile(supplies);
    int choice;

    do {
        printf("----------------------------\n");
        printf("|       1. Display Supplies    |\n");
        printf("|       2. Exit                |\n");
        printf("----------------------------\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

       if (scanf("%d", &choice) != 1) {
            printf("Invalid input. Please enter a number.\n");
            clearInputBuffer();
            continue;
        }
        clearInputBuffer();

        if (choice < 1 || choice > 2) {
            printf("Invalid choice. Please try again!\n");
            continue;
        }

        switch (choice) {
            case 1:
                displaySupplies(supplies, numSupplies);
                break;
            case 2:
                saveToFile(supplies, numSupplies);
                printf("Data saved. Exiting inventory management.\n");
                break;
            default:
                printf("Invalid choice. Try again.\n");
        }
    } while (choice != 2);
}

void PatientMenu(const char *storedUser) {
    int choice;

    do {
        printf("--------------------------------------------------\n");
        printf("|                  Patient Menu                   |\n");
        printf("--------------------------------------------------\n");
        printf("|     1. Appointment Management                   |\n");
        printf("|     2. Electronic Health Records (EHR)          |\n");
        printf("|     3. Billing Management                       |\n");
        printf("|     4. Exit                                     |\n");
        printf("--------------------------------------------------\n");
        printf("Select your choice to continue: ");

        if (scanf("%d", &choice) != 1) {
            printf("Invalid input. Please enter a number.\n");
            clearInputBuffer();
            continue;
        }

        if (choice < 1 || choice > 4) {
            printf("Invalid Input. Please try again!\n");
            continue;
        }

        switch (choice) {
            case 1:
                printf("Directing to Appointment Management...\n");
                PatientAppointmentMenu(storedUser);
                break;
            case 2:
                printf("Directing to Electronic Health Records (EHR)...\n");
                SearchPatientsEHR();
                break;
            case 3:
                printf("Directing to Billing Management...\n");
                BillingManagement();
                break;
            case 4:
                printf("Exiting Program...\n");
                return;
            default:
                printf("Invalid choice. Try again.\n");
        }
    } while (1); 
}

void SearchPatientsEHR() {
    char filename[] = "Electronic Health Recods.txt";
    char name[30];

    printf("Please Search your name!!!\n");
    printf("Enter name: ");
    scanf("%s", name);

    while (getchar() != '\n');

    FILE *fptr = fopen(filename, "r");
    if (fptr == NULL) {
        printf("Could not open file %s\n", filename);
        return;
    }

    char line[256];
    int header_printed = 0;

    while (fgets(line, sizeof(line), fptr)) {
        char firstName[50], lastName[50], dateOfBirth[20], gender[10], condition[50], allergies[50], medication[50];

        sscanf(line, "%[^,], %[^,], %[^,], %[^,], %[^,], %[^,], %[^,]",
               firstName, lastName, dateOfBirth, gender, condition, allergies, medication);

        if (strcmp(name, firstName) == 0) {
            if (!header_printed) {
                printf("---------------------------------------------------------------------------------------------------------------\n");
                printf("  First name  |   Last name    |  Date of Birth  | Gender  |  Condition   |   Allergies   |    Prescription   |\n");
                printf("---------------------------------------------------------------------------------------------------------------\n");
                header_printed = 1;
            }
            printf("%-13s | %-14s | %-15s | %-7s | %-12s | %-13s | %-18s|\n",
               firstName, lastName, dateOfBirth, gender, condition, allergies, medication);
        }
    }

    if (!header_printed) {
        printf("No patients found with the name: %s\n", name);
    } else {
        printf("\n");
        viewAppointment(name);
    }

    fclose(fptr);
}

void DoctorMenu(char storedUser[]) {
    int choice;

    do {
        printf("--------------------------------------------------\n");
        printf("|                   Doctor Menu                   |\n");
        printf("--------------------------------------------------\n");
        printf("|     1. Doctor Scheduler                         |\n");
        printf("|     2. Secure EHR Access                        |\n");
        printf("|     3. Reporting and Analytics                  |\n");
        printf("|     4. Exit                                     |\n");
        printf("--------------------------------------------------\n");
        printf("Select your choice to continue: ");
        
        
        if (scanf("%d", &choice) != 1) {
            printf("Invalid input. Please enter a number.\n");
            clearInputBuffer();
            continue;
        }

        
        if (choice < 1 || choice > 4) {
            printf("Invalid Input. Please try again!\n");
            continue;
        }

        
        switch (choice) {
            case 1:
                printf("Directing to Doctor Scheduler...\n");
                DoctorMenuManage(storedUser);
                break;
            case 2:
                printf("Directing to Secure EHR Access...\n");
                electronichealthrecords();
                break;
            case 3:
                printf("Directing to Reporting and Analytics...\n");
                DoctorReportingAnalytics();
                break;
            case 4:
                printf("Exiting Program...\n");
                return;
            default:
                printf("Invalid choice. Try again.\n");
        }
    } while (choice != 4);
}

void DoctorMenuManage(char doctor_name[]) {
    struct Schedule schedules[100];
    int numSchedules = 0;
    int choice;

    do {
        printf("----------------------------\n");
        printf("|       1. Make schedules  |\n");
        printf("|       2. Remove schedules|\n");
        printf("|       3. View schedules  |\n");
        printf("|       4. Exit            |\n");
        printf("----------------------------\n");
        printf("Enter your choice: ");

        if (scanf("%d", &choice) != 1) {
            printf("Invalid input. Please enter a number.\n");
            clearInputBuffer();
            continue;
        }

        if (choice < 1 || choice > 4) {
            printf("Invalid Input. Please try again!\n");
            continue;
        }

        switch (choice) {
            case 1:
                DoctorMakeSchedules(schedules, &numSchedules, doctor_name);
                break;
            case 2:
                DoctorRemoveSchedules(schedules, &numSchedules, doctor_name);
                break;
            case 3:
                DoctorViewSchedules(doctor_name);
                break;
            case 4:
                printf("Exiting schedule management.\n");
                break;
            default:
                printf("Invalid choice. Try again.\n");
        }
    } while (choice != 4);
}

void DoctorMakeSchedules(struct Schedule schedules[], int *numSchedules, const char *doctor_name) {
    if (*numSchedules >= 100) {
        printf("Schedule limit reached.\n");
        return;
    }

    struct Schedule newSchedule;

    printf("Enter day: ");
    scanf("%s", newSchedule.day);
    printf("Enter date (YYYY-MM-DD): ");
    scanf("%s", newSchedule.date);
    printf("Enter time slot: ");
    scanf("%s", newSchedule.time_slot);

    schedules[*numSchedules] = newSchedule;
    (*numSchedules)++;

    printf("Schedule added successfully.\n");
    DoctorSaveSchedulesToFile(schedules, *numSchedules, doctor_name);
}

void DoctorViewSchedules(const char *doctor_name) {
    char filename[120];
    snprintf(filename, sizeof(filename), "%s-schedules.txt", doctor_name);

    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        printf("Could not open %s for reading.\n", filename);
        return;
    }

    printf("No | Date         | Day     | Time Slot   |\n");
    printf("------------------------------------------\n");

    char line[256];
    int lineNum = 1;
    while (fgets(line, sizeof(line), file)) {
        struct Schedule schedule;
        sscanf(line, "%[^,],%[^,],%[^,\n]", schedule.day, schedule.date, schedule.time_slot);
        printf("%-2d | %-12s | %-7s | %-11s |\n", lineNum, schedule.date, schedule.day, schedule.time_slot);
        lineNum++;
    }

    fclose(file);
}

void DoctorSaveSchedulesToFile(struct Schedule schedules[], int numSchedules, const char *doctor_name) {
    char filename[120];
    snprintf(filename, sizeof(filename), "%s-schedules.txt", doctor_name);

    FILE *file = fopen(filename, "a"); 
    if (file == NULL) {
        printf("Error opening %s for writing.\n", filename);
        return;
    }

    
    struct Schedule newSchedule = schedules[numSchedules - 1];
    fprintf(file, "%s,%s,%s\n", newSchedule.day, newSchedule.date, newSchedule.time_slot);

    fclose(file);
    printf("Schedules saved to %s successfully.\n", filename);
}

void LoadSchedulesFromFile(struct Schedule schedules[], int *numSchedules, const char *doctor_name) {
    char filename[120];
    snprintf(filename, sizeof(filename), "%s-schedules.txt", doctor_name);

    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        
        return;
    }

    while (fscanf(file, "%[^,],%[^,],%s\n", schedules[*numSchedules].day, schedules[*numSchedules].date, schedules[*numSchedules].time_slot) == 3) {
        (*numSchedules)++;
    }

    fclose(file);
}

void DoctorRemoveSchedules(struct Schedule schedules[], int *numSchedules, const char *doctor_name) {
    char filename[120];
    snprintf(filename, sizeof(filename), "%s-schedules.txt", doctor_name);

    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        printf("Could not open %s for reading.\n", filename);
        return;
    }

    int actualNumSchedules = 0;
    char line[256];
    while (fgets(line, sizeof(line), file)) {
        struct Schedule schedule;
        sscanf(line, "%[^,],%[^,],%[^,\n]", schedule.day, schedule.date, schedule.time_slot);
        actualNumSchedules++;
    }
    fclose(file);

    viewSchedules(doctor_name);

    int choice;
    printf("Input number of the schedule you want to remove: ");
    scanf("%d", &choice);

    if (choice < 1 || choice > actualNumSchedules) {
        printf("Invalid choice. No schedule removed.\n");
        return;
    }

    file = fopen(filename, "r");
    if (file == NULL) {
        printf("Error opening file for removal.\n");
        return;
    }

    struct Schedule tempSchedules[100];
    int tempNumSchedules = 0;
    int lineNum = 1;
    while (fgets(line, sizeof(line), file)) {
        if (lineNum != choice) {
            sscanf(line, "%[^,],%[^,],%[^,\n]", tempSchedules[tempNumSchedules].day, tempSchedules[tempNumSchedules].date, tempSchedules[tempNumSchedules].time_slot);
            tempNumSchedules++;
        }
        lineNum++;
    }
    fclose(file);

    file = fopen(filename, "w");
    if (file == NULL) {
        printf("Error opening file for writing.\n");
        return;
    }

    for (int i = 0; i < tempNumSchedules; i++) {
        fprintf(file, "%s,%s,%s\n", tempSchedules[i].day, tempSchedules[i].date, tempSchedules[i].time_slot);
    }
    fclose(file);

    for (int i = choice - 1; i < *numSchedules - 1; i++) {
        schedules[i] = schedules[i + 1];
    }

    (*numSchedules)--;
    printf("Schedule removed successfully.\n");
}

int electronichealthrecords(){
    struct HealthRecord record;

    FILE *fptr;
    fptr = fopen("Electronic Health Recods.txt", "a");
    if (fptr == NULL){
        printf("Error opening file for writing.\n");
        return 1;
    }
    printf("---------------------------------------------\n");
    printf("|          Electronic Health Record:        |\n");
    printf("---------------------------------------------\n");

    printf("---------------------------------------------\n");
    printf("|     Medical History Form: \n");
    printf("| Please enter patient First Name: ");
    scanf("%49s", record.medicalHistoryPatientFirstName);
    printf("| Please enter patient Last Name: ");
    scanf("%49s", record.medicalHistoryPatientLastName);
    printf("| Please enter patient Gender:");
    scanf("%9s", record.gender);
    printf("| Please enter patient Birthdate (dd/mm/yyyy): ");
    scanf("%d/%d/%d", &record.birthday, &record.birthmonth, &record.birthyear);
       if (!validdate(record.birthday, record.birthmonth, record.birthyear)) {
        printf("Invalid birth date. Please try again...\n");
        return 1;
    }
    while (getchar() != '\n');
    printf("| What symptoms/conditions do the patient have?: ");
    gets(record.medicalHistory);
        if (record.medicalHistory[0] == '\n') {
        strcpy(record.medicalHistory, "None");
    } else {
        record.medicalHistory[strcspn(record.medicalHistory, "\n")] = '\0';  
    }
    printf("| Please enter patient Allergies: ");
    gets(record.allergies);
     if (record.allergies[0] == '\n') {
        strcpy(record.allergies, "None");
    } else {
        record.allergies[strcspn(record.allergies, "\n")] = '\0';  
    }
    printf("| Please enter patient Medication: ");
    gets(record.medication);
     if (record.medication[0] == '\n') {
        strcpy(record.medication, "None");
    } else {
        record.medication[strcspn(record.medication, "\n")] = '\0';  
    }
    printf("| Please enter patient Past Procedures: ");
    gets(record.pastProcedure);
     if (record.pastProcedure[0] == '\n') {
        strcpy(record.pastProcedure, "None");
    } else {
        record.pastProcedure[strcspn(record.pastProcedure, "\n")] = '\0';  
    }
    printf("| Please enter patient Diagnostic Reports: ");
    gets(record.diagnosticReports);
     if (record.diagnosticReports[0] == '\n') {
        strcpy(record.diagnosticReports, "None");
    } else {
        record.diagnosticReports[strcspn(record.diagnosticReports, "\n")] = '\0';  
    }
    printf("---------------------------------------------\n");


    fprintf(fptr, "%s, %s, %02d/%02d/%04d, %s, %s, %s, %s, %s, %s\n", record.medicalHistoryPatientFirstName, record.medicalHistoryPatientLastName, record.birthday, record.birthmonth, record.birthyear, record.gender, record.medicalHistory, record.allergies, record.medication, record.pastProcedure, record.diagnosticReports);
    fclose(fptr);

    printf("Patient Electronic Health Records Updated! Going back to main menu...\n");
    printf("\n");
}

void NurseMenu() {
    int choice;

    do {
        printf("--------------------------------------------------\n");
        printf("|                Staff Nurse Menu                 |\n");
        printf("--------------------------------------------------\n");
        printf("|     1. Doctor Scheduler                         |\n");
        printf("|     2. Inventory Management                     |\n");
        printf("|     3. Reporting and Analytics                  |\n");
        printf("|     4. Exit                                     |\n");
        printf("--------------------------------------------------\n");
        printf("Select your choice to continue: ");

        if (scanf("%d", &choice) != 1) {
            printf("Invalid input. Please enter a number.\n");
            clearInputBuffer();
            continue;
        }

        if (choice < 1 || choice > 4) {
            printf("Invalid Input. Please try again!\n");
            continue;
        }

        switch (choice) {
            case 1:
                printf("Directing to Doctor Scheduler...\n");
                Doctorlogin();
                break;
            case 2:
                printf("Directing to Inventory Management...\n");
                InventoryManagement();
                break;
            case 3:
                printf("Directing to Reporting and Analytics...\n");
                NurseReportingAnalytics();
                break;
            case 4:
                printf("Exiting Program...\n");
                return;
            default:
                printf("Invalid choice. Try again.\n");
        }
    } while (1); 
}

void NurseReportingAnalytics() {
    int choice;

    do {
        printf("--------------------------------------------------\n");
        printf("|           Reporting and Analytics               |\n");
        printf("--------------------------------------------------\n");
        printf("|     1. View all patient                         |\n");
        printf("|     2. Search by Patient Prescription           |\n");
        printf("|     3. Exit                                     |\n");
        printf("--------------------------------------------------\n");
        printf("Select your choice to continue: ");
        
        
        if (scanf("%d", &choice) != 1) {
            printf("Invalid input. Please enter a number.\n");
            clearInputBuffer();
            continue;
        }

        
        if (choice < 1 || choice > 3) {
            printf("Invalid Input. Please try again!\n");
            continue;
        }

        
        switch (choice) {
            case 1:
                printf("Directing View all Patients...\n");
                NurseViewAllPatients();
                break;
            case 2:
                printf("Directing to Search by patient prescription...\n");
                NurseSearchPatients();
                break;
            case 3:
                printf("Exiting back to main menu...\n");
                return;
            default:
                printf("Invalid choice. Try again.\n");
        }
    } while (choice != 3);
}

void NurseViewAllPatients() {
    char filename[] = "Electronic Health Recods.txt";

    printf("Viewing All Possible Patients\n");

    FILE *fptr = fopen(filename, "r");
    if (fptr == NULL) {
        printf("Could not open file %s\n", filename);
        return;
    }

    char line[256];

    printf("--------------------------------------------------------------------------------------------\n");
    printf("|   First name   |   Last name    |   Condition  |    Prescription    | Diagnostic Reports |\n");
    printf("--------------------------------------------------------------------------------------------\n");

    while (fgets(line, sizeof(line), fptr)) {
        char firstName[50], lastName[50], dateOfBirth[20], gender[10], condition[50], allergies[50], medication[50], pastProcedure[50], diagnosticReports[50];

        
        sscanf(line, "%[^,], %[^,], %[^,], %[^,], %[^,], %[^,], %[^,], %[^,], %[^\n]",
               firstName, lastName, dateOfBirth, gender, condition, allergies, medication, pastProcedure, diagnosticReports);

       
        printf("| %-14s | %-14s | %-12s | %-18s | %-18s |\n",
               firstName, lastName, condition, medication, diagnosticReports);
    }
    printf("----------------------------------------------------------------------------------\n");

    fclose(fptr);
}

void NurseSearchPatients() {
    char filename[] = "Electronic Health Recods.txt";
    char prescription[50];

    printf("Please search by Patient Prescription: ");

    getchar();
    
    fgets(prescription, sizeof(prescription), stdin);

    size_t len = strlen(prescription);
    if (len > 0 && prescription[len - 1] == '\n') {
        prescription[len - 1] = '\0';
    }

    FILE *fptr = fopen(filename, "r");
    if (fptr == NULL) {
        printf("Could not open file %s\n", filename);
        return;
    }

    char line[256];
    int found = 0;

    while (fgets(line, sizeof(line), fptr)) {
        char firstName[50], lastName[50], dateOfBirth[20], gender[10], condition[50], allergies[50], medication[50], pastProcedure[50], diagnosticReports[50];

        sscanf(line, "%[^,], %[^,], %[^,], %[^,], %[^,], %[^,], %[^,], %[^,], %[^\n]",
               firstName, lastName, dateOfBirth, gender, condition, allergies, medication, pastProcedure, diagnosticReports);
               
        if (strcmp(medication, prescription) == 0) {
            if (!found) {
                printf("-------------------------------------------------------------------------------------------\n");
                printf("|   First name   |   Last name    |   Condition  |    Prescription    | Diagnostic Reports |\n");
                printf("-------------------------------------------------------------------------------------------\n");
                found = 1;
            }
            printf("| %-14s | %-14s | %-12s | %-18s | %-18s |\n",
                   firstName, lastName, condition, medication, diagnosticReports);
        }
    }

    if (!found) {
        printf("No patients found with the medication: %s\n", prescription);
    } else {
        printf("-------------------------------------------------------------------------------------------\n");
    }

    fclose(fptr);
}

int Doctorlogin() {
    struct Doctor doctors[100];
    int numDoctors = 0;

    loadDoctors(doctors, &numDoctors, "doctorregister.txt");
    
    if (numDoctors == 0) {
        printf("No doctors found in the file.\n");
        return 1;
    }

    displayDoctors(doctors, numDoctors);
    
    int choice = chooseDoctor(doctors, numDoctors);
    if (choice >= 0 && choice < numDoctors) {
        printf("You selected: %s\n", doctors[choice].name);
        const char *doctor_name = doctors[choice].name;
        viewSchedules(doctor_name); 
    } else {
        printf("Invalid choice.\n");
    }

    return 0;
}

void viewSchedules(const char *doctor_name) {
    struct Schedule schedule[100];
    int numSchedules = loadSchedule(schedule, doctor_name);

    if (numSchedules == 0) {
        printf("No schedules found for Dr. %s.\n", doctor_name);
        return;
    }

    printf("No | Date         | Day     | Time Slot   |\n");
    printf("------------------------------------------\n");

    for (int i = 0; i < numSchedules; i++) {
        printf("%-2d | %-12s | %-7s | %-11s |\n", i + 1, schedule[i].date, schedule[i].day, schedule[i].time_slot);
    }
}

int loadSchedule(struct Schedule schedule[], const char *doctor_name) {
    char filename[120];
    snprintf(filename, sizeof(filename), "%s-schedules.txt", doctor_name);

    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        printf("Could not open %s for reading.\n", filename);
        return 0;
    }

    int count = 0;
    char line[256];
    while (fgets(line, sizeof(line), file) && count < 100) {
        sscanf(line, "%[^,],%[^,],%[^,\n]", schedule[count].day, schedule[count].date, schedule[count].time_slot);
        count++;
    }

    fclose(file);
    return count;
}

void PatientAppointmentMenu(const char *patient_name) {
    int choice;

    while (1) {
        printf("--------------------------------------------------\n");
        printf("|            Patient Appointment Menu             |\n");
        printf("--------------------------------------------------\n");
        printf("|     1. Make Appointment                         |\n");
        printf("|     2. View Appointment                         |\n");
        printf("|     3. Reschedule Appointment                   |\n");
        printf("|     4. Cancel Appointment                       |\n");
        printf("|     5. Exit                                     |\n");
        printf("--------------------------------------------------\n");
        printf("Select your choice to continue: ");

        if (scanf("%d", &choice) != 1) {
            printf("Invalid input. Please enter a number.\n");
            clearInputBuffer();
            continue;
        }

        if (choice < 1 || choice > 5) {
            printf("Invalid Input. Please try again!\n");
            continue;
        }

        switch (choice) {
            case 1:
                printf("Making Appointment for %s...\n", patient_name);
                makeAppointment(patient_name);
                break;
            case 2:
                printf("Viewing Appointment for %s...\n", patient_name);
                viewAppointment(patient_name);
                break;
            case 3:
                printf("Rescheduling Appointment for %s...\n", patient_name);
                rescheduleAppointment(patient_name);
                break;
            case 4:
                printf("Cancelling Appointment for %s...\n", patient_name);
                cancelAppointment(patient_name);
                break;
            case 5:
                printf("Exiting...\n");
                return;
            default:
                printf("Invalid choice. Try again.\n");
        }
    }
}

void makeAppointment(const char *patient_name) {
    struct Doctor doctors[100];
    int numDoctors = 0;
    loadDoctors(doctors, &numDoctors, "doctorregister.txt");

    if (numDoctors == 0) {
        printf("No doctors found in the file.\n");
        return;
    }

    displayDoctors(doctors, numDoctors);
    int choice = chooseDoctor(doctors, numDoctors);
    if (choice < 0 || choice >= numDoctors) {
        printf("Invalid doctor choice.\n");
        return;
    }

    const char *doctor_name = doctors[choice].name;

    struct Schedule schedule[100];
    int numSchedules = loadSchedule(schedule, doctor_name);

    if (numSchedules == 0) {
        printf("No schedules available for Dr. %s.\n", doctor_name);
        return;
    }

    printf("No | Date         | Day     | Time Slot   |\n");
    printf("------------------------------------------\n");

    for (int i = 0; i < numSchedules; i++) {
        printf("%-2d | %-12s | %-7s | %-11s |\n", i + 1, schedule[i].date, schedule[i].day, schedule[i].time_slot);
    }

    printf("Choose a slot by number: ");
    scanf("%d", &choice);

    if (choice < 1 || choice > numSchedules) {
        printf("Invalid choice.\n");
        return;
    }

    struct Schedule selected = schedule[choice - 1];

    FILE *file = fopen("patient_appointments.txt", "a");
    if (file == NULL) {
        printf("Could not open patient_appointments.txt for writing.\n");
        return;
    }

    fprintf(file, "%s,%s,%s,%s\n", doctor_name, patient_name, selected.date, selected.time_slot);
    printf("Appointment made with Dr. %s on %s at %s.\n", doctor_name, selected.date, selected.time_slot);

    fclose(file);
}

void viewAppointment(const char *patient_name) {
    FILE *file = fopen("patient_appointments.txt", "r");
    if (file == NULL) {
        printf("Could not open patient_appointments.txt for reading.\n");
        return;
    }

    printf("Your appointments:\n");
    printf("Doctor     | Date       | Time Slot   |\n");
    printf("--------------------------------------\n");

    char line[256];
    while (fgets(line, sizeof(line), file)) {
        char doctor_name[100];
        char patient[100];
        char date[11];
        char time_slot[20];
        sscanf(line, "%[^,],%[^,],%[^,],%[^,\n]", doctor_name, patient, date, time_slot);
        if (strcmp(patient, patient_name) == 0) {
            printf("%-10s | %-10s | %-11s |\n", doctor_name, date, time_slot);
        }
    }

    fclose(file);
}

void rescheduleAppointment(const char *patient_name) {
    FILE *file = fopen("patient_appointments.txt", "r");
    if (file == NULL) {
        printf("Could not open patient_appointments.txt for reading.\n");
        return;
    }

    struct Appointment appointments[100];
    int numAppointments = 0;

    char line[256];
    while (fgets(line, sizeof(line), file) && numAppointments < 100) {
        sscanf(line, "%[^,],%[^,],%[^,],%[^,\n]", appointments[numAppointments].doctor_name, appointments[numAppointments].patient_name, appointments[numAppointments].date, appointments[numAppointments].time_slot);
        numAppointments++;
    }

    fclose(file);

    printf("Your appointments:\n");
    printf("No | Doctor     | Date       | Time Slot   |\n");
    printf("-------------------------------------------\n");

    int count = 1;
    for (int i = 0; i < numAppointments; i++) {
        if (strcmp(appointments[i].patient_name, patient_name) == 0) {
            printf("%-2d | %-10s | %-10s | %-11s |\n", count, appointments[i].doctor_name, appointments[i].date, appointments[i].time_slot);
            count++;
        }
    }

    if (count == 1) {
        printf("No appointments to reschedule.\n");
        return;
    }

    int choice;
    printf("Choose an appointment to reschedule by number: ");
    scanf("%d", &choice);

    if (choice < 1 || choice >= count) {
        printf("Invalid choice.\n");
        return;
    }

    struct Appointment selectedAppointment;
    count = 1;
    for (int i = 0; i < numAppointments; i++) {
        if (strcmp(appointments[i].patient_name, patient_name) == 0) {
            if (count == choice) {
                selectedAppointment = appointments[i];
                break;
            }
            count++;
        }
    }

    struct Schedule schedule[100];
    int numSchedules = loadSchedule(schedule, selectedAppointment.doctor_name);

    if (numSchedules == 0) {
        printf("No schedules available for Dr. %s.\n", selectedAppointment.doctor_name);
        return;
    }

    printf("Available slots for Dr. %s:\n", selectedAppointment.doctor_name);
    printf("No | Date         | Day     | Time Slot   |\n");
    printf("------------------------------------------\n");

    for (int i = 0; i < numSchedules; i++) {
        printf("%-2d | %-12s | %-7s | %-11s |\n", i + 1, schedule[i].date, schedule[i].day, schedule[i].time_slot);
    }

    printf("Choose a new slot by number: ");
    scanf("%d", &choice);

    if (choice < 1 || choice > numSchedules) {
        printf("Invalid choice.\n");
        return;
    }

    struct Schedule newSchedule = schedule[choice - 1];

    for (int i = 0; i < numAppointments; i++) {
        if (strcmp(appointments[i].patient_name, patient_name) == 0) {
            if (strcmp(appointments[i].doctor_name, selectedAppointment.doctor_name) == 0 &&
                strcmp(appointments[i].date, selectedAppointment.date) == 0 &&
                strcmp(appointments[i].time_slot, selectedAppointment.time_slot) == 0) {
                strcpy(appointments[i].date, newSchedule.date);
                strcpy(appointments[i].time_slot, newSchedule.time_slot);
                break;
            }
        }
    }

    file = fopen("patient_appointments.txt", "w");
    if (file == NULL) {
        printf("Error opening file for writing.\n");
        return;
    }

    for (int i = 0; i < numAppointments; i++) {
        fprintf(file, "%s,%s,%s,%s\n", appointments[i].doctor_name, appointments[i].patient_name, appointments[i].date, appointments[i].time_slot);
    }
    fclose(file);

    printf("Appointment rescheduled successfully.\n");
}

void cancelAppointment(const char *patient_name) {
    FILE *file = fopen("patient_appointments.txt", "r");
    if (file == NULL) {
        printf("Could not open patient_appointments.txt for reading.\n");
        return;
    }

    struct Appointment appointments[100];
    int numAppointments = 0;

    char line[256];
    while (fgets(line, sizeof(line), file) && numAppointments < 100) {
        sscanf(line, "%[^,],%[^,],%[^,],%[^,\n]", appointments[numAppointments].doctor_name, appointments[numAppointments].patient_name, appointments[numAppointments].date, appointments[numAppointments].time_slot);
        numAppointments++;
    }

    fclose(file);

    printf("Your appointments:\n");
    printf("No | Doctor     | Date       | Time Slot   |\n");
    printf("-------------------------------------------\n");

    int count = 1;
    int appointmentIndices[100];

    for (int i = 0; i < numAppointments; i++) {
        if (strcmp(appointments[i].patient_name, patient_name) == 0) {
            printf("%-2d | %-10s | %-10s | %-11s |\n", count, appointments[i].doctor_name, appointments[i].date, appointments[i].time_slot);
            appointmentIndices[count - 1] = i;
            count++;
        }
    }

    if (count == 1) {
        printf("No appointments to cancel.\n");
        return;
    }

    int choice;
    printf("Choose an appointment to cancel by number: ");
    scanf("%d", &choice);

    if (choice < 1 || choice >= count) {
        printf("Invalid choice.\n");
        return;
    }

    int appointmentIndexToRemove = appointmentIndices[choice - 1]; 

    file = fopen("patient_appointments.txt", "w");
    if (file == NULL) {
        printf("Error opening file for writing.\n");
        return;
    }

    for (int i = 0; i < numAppointments; i++) {
        if (i != appointmentIndexToRemove) {
            fprintf(file, "%s,%s,%s,%s\n", appointments[i].doctor_name, appointments[i].patient_name, appointments[i].date, appointments[i].time_slot);
        }
    }

    fclose(file);

    printf("Appointment canceled successfully.\n");
}

void loadDoctors(struct Doctor doctors[], int *numDoctors, const char *filename) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        printf("Could not open %s for reading.\n", filename);
        return;
    }

    char line[100];
    while (fgets(line, sizeof(line), file) && *numDoctors < 100) {
        char *token = strtok(line, ",");
        if (token != NULL) {
            strncpy(doctors[*numDoctors].name, token, 100);
            token = strtok(NULL, ",");
            if (token != NULL) {
                strncpy(doctors[*numDoctors].id, token, 20);
            }
            (*numDoctors)++;
        }
    }

    fclose(file);
}

void displayDoctors(struct Doctor doctors[], int numDoctors) {
    for (int i = 0; i < numDoctors; i++) {
        printf("%d. %s\n", i + 1, doctors[i].name);
    }
}

int chooseDoctor(struct Doctor doctors[], int numDoctors) {
    int choice;
    printf("Input your choice: ");
    scanf("%d", &choice);
    return choice - 1;
}

void readAppointmentTrends(const char *filename) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        printf("Could not open %s for reading.\n", filename);
        return;
    }

    struct Appointment appointments[100];
    int numAppointments = 0;
    char line[256];

    
    while (fgets(line, sizeof(line), file) && numAppointments < 100) {
        sscanf(line, "%[^,],%[^,],%[^,],%[^,\n]", 
               appointments[numAppointments].doctor_name, 
               appointments[numAppointments].patient_name, 
               appointments[numAppointments].date, 
               appointments[numAppointments].time_slot);
        numAppointments++;
    }

    fclose(file);

    
    struct DateCount dateCounts[100] = {0};
    int numUniqueDates = 0;

    for (int i = 0; i < numAppointments; i++) {
        int found = 0;
        for (int j = 0; j < numUniqueDates; j++) {
            if (strcmp(appointments[i].date, dateCounts[j].date) == 0) {
                dateCounts[j].count++;
                found = 1;
                break;
            }
        }
        if (!found && numUniqueDates < 100) {
            strcpy(dateCounts[numUniqueDates].date, appointments[i].date);
            dateCounts[numUniqueDates].count = 1;
            numUniqueDates++;
        }
    }

    
    for (int i = 0; i < numUniqueDates - 1; i++) {
        for (int j = i + 1; j < numUniqueDates; j++) {
            if (dateCounts[j].count > dateCounts[i].count) {
                struct DateCount temp = dateCounts[i];
                dateCounts[i] = dateCounts[j];
                dateCounts[j] = temp;
            }
        }
    }

    
    printf("No Date         Appointments\n");
    for (int i = 0; i < numUniqueDates; i++) {
        printf("%d. %-12s %d\n", i + 1, dateCounts[i].date, dateCounts[i].count);
    }
}

void BillingManagement() {
    char input_name[20];
    char line[maxlinelength];
    char patient_name[20];
    int appointmentcount = 0;
    int insurance = 0;

    printf("Welcome to your billing management! Please input your name: ");
    scanf("%s", input_name);

    
    FILE *appointments_file = fopen("patient_appointments.txt", "r");
    if (appointments_file == NULL) {
        printf("Could not open appointments file.\n");
        return;
    }

    while (fgets(line, sizeof(line), appointments_file)) {
        
        sscanf(line, "%*[^,],%[^,]", patient_name);

        
        if (strcmp(patient_name, input_name) == 0) {
            appointmentcount++;
        }
    }
    fclose(appointments_file);

    
    FILE *register_file = fopen("patientregister.txt", "r");
    if (register_file == NULL) {
        printf("Could not open register file.\n");
        return;
    }

    while (fgets(line, sizeof(line), register_file)) {
        char registered_name[20];
        char surname[20];
        char insurance_status[4];

        
        sscanf(line, "%[^,],%[^,],%s", registered_name, surname, insurance_status);

        
        if (strcmp(registered_name, input_name) == 0) {
            if (strcmp(insurance_status, "yes") == 0) {
                insurance = 1;
            }
            break;
        }
    }
    fclose(register_file);

    if (appointmentcount > 0) {
        
        int total_bill = appointmentcount *BillPerAppointment;
        if (insurance) {
            total_bill -= InsuranceDiscount;
        }
        printf("Total bill for patient '%s' is: $%d\n", input_name, total_bill);
        printf("Please pay at the cashier! We accept cash, card, online banking, etc. Thank you! for using our service and Get well soon!\n");
    } else {
        printf("Patient named '%s' not found.\n", input_name);
    }
}

void DoctorReportingAnalytics () {
    int choice;

    do {
        printf("--------------------------------------------------\n");
        printf("|           Reporting and Analytics               |\n");
        printf("--------------------------------------------------\n");
        printf("|     1. View all patient                         |\n");
        printf("|     2. Search by Patient Conditions             |\n");
        printf("|     3. Exit                                     |\n");
        printf("--------------------------------------------------\n");
        printf("Select your choice to continue: ");
        
        
        if (scanf("%d", &choice) != 1) {
            printf("Invalid input. Please enter a number.\n");
            clearInputBuffer();
            continue;
        }

        
        if (choice < 1 || choice > 3) {
            printf("Invalid Input. Please try again!\n");
            continue;
        }

        
        switch (choice) {
            case 1:
                printf("Directing View all Patients...\n");
                DoctorViewAllPatients();
                break;
            case 2:
                printf("Directing to Search by patient conditions...\n");
                DoctorSearchPatients();
                break;
            case 3:
                printf("Exiting back to main menu...\n");
                return;
            default:
                printf("Invalid choice. Try again.\n");
        }
    } while (choice != 3);
}

void DoctorViewAllPatients() {
    char filename[] = "Electronic Health Recods.txt";

    FILE *fptr = fopen(filename, "r");
    if (fptr == NULL) {
        printf("Could not open file %s\n", filename);
        return;
    }

    char line[256];

    printf("------------------------------------------------------------------------------------------------------------------------------------------------------\n");
    printf("  First name  |   Last name    |  Date of Birth  | Gender  |  Condition   |   Allergies   |    Medication      | Past Procedure  | Diagnostic Reports\n");
    printf("------------------------------------------------------------------------------------------------------------------------------------------------------\n");

    while (fgets(line, sizeof(line), fptr)) {
        char firstName[50], lastName[50], dateOfBirth[20], gender[10], condition[50], allergies[50], medication[50], pastProcedure[50], diagnosticReports[50];

        sscanf(line, "%[^,], %[^,], %[^,], %[^,], %[^,], %[^,], %[^,], %[^,], %[^\n]",
               firstName, lastName, dateOfBirth, gender, condition, allergies, medication, pastProcedure, diagnosticReports);

        printf("%-13s | %-14s | %-15s | %-7s | %-12s | %-13s | %-18s | %-15s | %-17s\n",
               firstName, lastName, dateOfBirth, gender, condition, allergies, medication, pastProcedure, diagnosticReports);
    }

    fclose(fptr);
}

void DoctorSearchPatients() {
    char filename[] = "Electronic Health Recods.txt";
    char conditions[30];

    printf("Please Search Patient by Their Conditions!!!\n");
    printf("Enter Conditions: ");
    scanf("%s", conditions);

    FILE *fptr = fopen(filename, "r");
    if (fptr == NULL) {
        printf("Could not open file %s\n", filename);
        return;
    }

    char line[256];
    int header_printed = 0;

    while (fgets(line, sizeof(line), fptr)) {
        char firstName[50], lastName[50], dateOfBirth[20], gender[10], condition[50], allergies[50], medication[50], pastProcedure[50], diagnosticReports[50];

        sscanf(line, "%[^,], %[^,], %[^,], %[^,], %[^,], %[^,], %[^,], %[^,], %[^\n]",
               firstName, lastName, dateOfBirth, gender, condition, allergies, medication, pastProcedure, diagnosticReports);

        if (strcmp(condition, conditions) == 0) {
            if (!header_printed) {
                printf("-------------------------------------------------------------------------------------------------------------------------------------------------------\n");
                printf("  First name  |   Last name    |  Date of Birth  | Gender  |  Condition   |   Allergies   |    Medication      | Past Procedure  | Diagnostic Reports |\n");
                printf("-------------------------------------------------------------------------------------------------------------------------------------------------------\n");
                header_printed = 1;
            }
            printf("%-13s | %-14s | %-15s | %-7s | %-12s | %-13s | %-18s | %-15s | %-17s\n",
               firstName, lastName, dateOfBirth, gender, condition, allergies, medication, pastProcedure, diagnosticReports);
        }
    }

    if (!header_printed) {
        printf("No patients found with the condition: %s\n", conditions);
    }

    fclose(fptr);
}

void RegisterNewUsers() {
    int choice1;
    
    do {
        printf("We have 4 options to choose from. Select your choice:\n");
        printf("-------------------------------------\n");
        printf("|   Hospital Administrator Menu:    |\n");
        printf("-------------------------------------\n");
        printf("|       1. Register Patient         |\n");
        printf("|       2. Register Doctor          |\n");
        printf("|       3. Register Staff Nurse     |\n");
        printf("|       4. Exit                     |\n");
        printf("-------------------------------------\n");
        printf("Enter your choice: ");

        if (scanf("%d", &choice1) != 1) {
            printf("Invalid input. Please enter a number.\n");
            clearInputBuffer();
            continue;
        }

        
        if (choice1 < 1 || choice1 > 4) {
            printf("Invalid Input. Please try again!\n");
            continue;
        }

        switch (choice1) {
            case 1:
                printf("Registering Patient..\n");
                patientregister();
                break;
            case 2:
                printf("Registering Doctor..\n");
                doctorregister();
                break;
            case 3:
                printf("Registering Staff Nurse..\n");
                nurseregister();
                break;
            case 4:
                printf("Exiting back to main menu..\n");
                return;
                break;
            default:
                printf("Invalid choice, please try again!\n");
        }
    } while (choice1 != 4);
}

int patientregister() {
    char user[20];
    char pass[20];
    char storedUser[20];
    char filename[] = "patientregister.txt";
    char line[50];
    char insurance [20];
    int Duplicate = 0;

    printf("Please enter your username: ");
    scanf("%19s", user);
    printf("Please enter your password: ");
    scanf("%19s", pass);
    printf("Does patient have insurance claims? (yes / no) : ");
    scanf("%19s", insurance);

    FILE *patientregister = fopen(filename, "r");
    if (patientregister != NULL) {
        while (fgets(line, sizeof(line), patientregister)) {
            line[strcspn(line, "\n")] = '\0';

            sscanf(line, "%19[^,]", storedUser);
            if (strcmp(user, storedUser) == 0) {
                printf("Username already exists. Please choose a different username.\n");
                Duplicate = 1;
                break;
            }
        }
        fclose(patientregister);
    } else {
        printf("Error reading or opening file.\n");
        return 1;
    }

    if (Duplicate) {
        return 1;
    }

    patientregister = fopen(filename, "a");
    if (patientregister != NULL) {
        fprintf(patientregister, "%s, %s, %s\n", user, pass, insurance);
        fclose(patientregister);
        printf("Registration successful!\n");
    } else {
        printf("Error opening file for writing.\n");
        return 1;
    }

    return 0;
}

int doctorregister(){
    char user[20];
    char pass[20];
    char storedUser[20];
    char filename[] = "doctorregister.txt";
    char line[50];
    int Duplicate = 0;

    printf("Please enter your username: ");
    scanf("%19s", user);
    printf("Please enter your password: ");
    scanf("%19s", pass);

    FILE *doctorregister = fopen(filename, "r");
    if (doctorregister != NULL) {
        while (fgets(line, sizeof(line), doctorregister)) {
            line[strcspn(line, "\n")] = '\0';

            sscanf(line, "%19[^,]", storedUser);
            if (strcmp(user, storedUser) == 0) {
                printf("Username already exists. Please choose a different username.\n");
                Duplicate = 1;
                break;
            }
        }
        fclose(doctorregister);
    } else {
        printf("Error reading or opening file.\n");
        return 1;
    }

    if (Duplicate) {
        return 1;
    }

    doctorregister = fopen(filename, "a");
    if (doctorregister != NULL) {
        fprintf(doctorregister, "%s, %s\n", user, pass);
        fclose(doctorregister);
        printf("Registration successful!\n");
    } else {
        printf("Error opening file for writing.\n");
        return 1;
    }

    return 0;
}

int nurseregister(){
    char user[20];
    char pass[20];
    char storedUser[20];
    char filename[] = "nurseregister.txt";
    char line[50];
    int Duplicate = 0;

    printf("Please enter your username: ");
    scanf("%19s", user);
    printf("Please enter your password: ");
    scanf("%19s", pass);

    FILE *nurseregister = fopen(filename, "r");
    if (nurseregister != NULL) {
        while (fgets(line, sizeof(line), nurseregister)) {
            line[strcspn(line, "\n")] = '\0';

            sscanf(line, "%19[^,]", storedUser);
            if (strcmp(user, storedUser) == 0) {
                printf("Username already exists. Please choose a different username.\n");
                Duplicate = 1;
                break;
            }
        }
        fclose(nurseregister);
    } else {
        printf("Error reading or opening file.\n");
        return 1;
    }

    if (Duplicate) {
        return 1;
    }

    nurseregister = fopen(filename, "a");
    if (nurseregister != NULL) {
        fprintf(nurseregister, "%s, %s\n", user, pass);
        fclose(nurseregister);
        printf("Registration successful!\n");
    } else {
        printf("Error opening file for writing.\n");
        return 1;
    }

    return 0;
}

int HospitalAdministratorCheck() {
    char HospitalID[20];
    char HospitalPass[20];
    char correct_UserHospitalID[] = "a";
    char correct_UserHospitalPass[] = "aaaa";
    int HospitalAttempt = 0;
    int choice;

    printf("Welcome to Hospital Administrator\n");
    while (HospitalAttempt < MAXATTEMPT) {
        printf("----------------------------------\n");
        printf("|              Menu:             |\n");
        printf("----------------------------------\n");
        printf("|             1. Login           |\n");
        printf("|             2. Exit            |\n");
        printf("----------------------------------\n");
        printf("Enter your choice: ");

        if (scanf("%d", &choice) != 1) {
            printf("Invalid input. Please enter a number.\n");
           
            while (getchar() != '\n');
            continue;
        }

        if (choice == 2) {
            printf("Exiting program.\n");
            return 0;
        }

        if (choice == 1) {
            printf("Please input user ID: ");
            scanf("%19s", HospitalID);
            printf("Please enter your password: ");
            scanf("%19s", HospitalPass);

            if (strcmp(HospitalID, correct_UserHospitalID) == 0 && strcmp(HospitalPass, correct_UserHospitalPass) == 0) {
                printf("Logged in successfully\n");
                FILE *hls = fopen("HLS.txt", "a");
                if (hls != NULL) {
                    fprintf(hls, "UserID: %s, Password: %s\n", HospitalID, HospitalPass);
                    fclose(hls);
                } else {
                    printf("Error opening file.\n");
                }
                HospitalAdministratorMenu();
                break;
            } else {
                HospitalAttempt++;
                printf("Wrong userID or Password.\n");
            }
        } else {
            printf("Invalid choice. Please select 1 to Login or 2 to Exit.\n");
        }

    
        while (getchar() != '\n');
    }

    if (HospitalAttempt == MAXATTEMPT) {
        printf("\nToo many failed attempts. You are kicked out, please try again later!\n");
    }

    return 0;
}

void clearInputBuffer() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
}

int PatientCheck() {
    char user[20];
    char pass[20];
    char storedUser[20];
    char storedPass[20];
    char storedInsurance[20];
    char filename[] = "patientregister.txt";
    char line[50];

    printf("Welcome to Patient Menu. Please Proceed!\n");
    printf("Enter your username: ");
    scanf("%19s", user);
    clearInputBuffer(); 
    printf("Enter your password: ");
    scanf("%19s", pass);
    clearInputBuffer(); 

    FILE *patientregister = fopen(filename, "r");
    if (patientregister == NULL) {
        printf("Error reading or opening file.\n");
        return 1;
    }

    int loginSuccess = 0;
    while (fgets(line, sizeof(line), patientregister)) {
        line[strcspn(line, "\n")] = '\0';

        if (sscanf(line, "%19[^,], %19[^,], %19s", storedUser, storedPass, storedInsurance) != 3) {
            continue;
        }

        if (strcmp(user, storedUser) == 0 && strcmp(pass, storedPass) == 0) {
            printf("Login successful! Welcome patient %s!\n", storedUser); 
            loginSuccess = 1;
            break;
        }
    }

    fclose(patientregister);

    if (loginSuccess) {
        PatientMenu(storedUser);
        return 0;
    } else {
        printf("Wrong Username or Password. Please try again!\n");
        return 1;
    }
}

int DoctorCheck() {
    char user[20];
    char pass[20];
    char storedUser[20];
    char storedPass[20];
    char filename[] = "doctorregister.txt";
    char line[50];

    printf("Welcome to Doctor Menu. Please Proceed!\n");
    printf("Enter your username: ");
    scanf("%19s", user);
    printf("Enter your password: ");
    scanf("%19s", pass);

    FILE *doctorregister = fopen(filename, "r");
    if (doctorregister == NULL) {
        printf("Error reading or opening file.\n");
        return 1;
    }

    int loginSuccess = 0;
    while (fgets(line, sizeof(line), doctorregister)) {
        line[strcspn(line, "\n")] = '\0';

        sscanf(line, "%19[^,],%19s", storedUser, storedPass);

        if (strcmp(user, storedUser) == 0 && strcmp(pass, storedPass) == 0) {
            printf("Login successful, welcome doctor %s!\n", storedUser);
            loginSuccess = 1;
            fclose(doctorregister);
            DoctorMenu(storedUser);
            return 0;
        }
    }

    fclose(doctorregister);
    printf("Wrong Username or Password. Please try again!\n");
    return 1;
}

int NurseCheck() {
    char user[20];
    char pass[20];
    char storedUser[20];
    char storedPass[20];
    char filename[] = "nurseregister.txt";
    char line[50];

    printf("Welcome to Staff Nurse Menu. Please Proceed!\n");
    printf("Enter your username: ");
    scanf("%19s", user);
    printf("Enter your password: ");
    scanf("%19s", pass);

    FILE *nurseregister = fopen(filename, "r");
    if (nurseregister == NULL) {
        printf("Error reading or opening file.\n");
        return 1;
    }

    int loginSuccess = 0;
    while (fgets(line, sizeof(line), nurseregister)) {
        line[strcspn(line, "\n")] = '\0';

        char *commaPos = strchr(line, ',');
        if (commaPos == NULL || strchr(commaPos + 1, ',') != NULL) {
            continue;
        }

        sscanf(line, "%19[^,], %19s", storedUser, storedPass);

        if (strlen(storedUser) == 0 || strlen(storedPass) == 0) {
            continue;
        }
        if (strcmp(user, storedUser) == 0 && strcmp(pass, storedPass) == 0) {
            printf("Login successful, welcome nurse %s!\n", storedUser);
            loginSuccess = 1;
            break;
        }
    }

    fclose(nurseregister);

    if (loginSuccess) {
        NurseMenu();
        return 0;
    } else {
        printf("Wrong Username or Password. Please try again!\n");
        return 1;
    }
}
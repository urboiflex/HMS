#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "header.h"
#define MAXATTEMPT 3
#define BillPerAppointment 100
#define maxlinelength 100
#define InsuranceDiscount 80

int main() {
    int choice;
    char buffer[10];

    do {
        printf("Welcome to Hospital Management System. Please Proceed\n");
        printf("-----------------------------------------------------\n");
        printf("|          Hospital Management System Menu:          |\n");
        printf("-----------------------------------------------------\n");
        printf("|           1. Hospital Administrator                |\n");
        printf("|           2. Patient                               |\n");
        printf("|           3. Doctor                                |\n");
        printf("|           4. Staff Nurse                           |\n");
        printf("|           5. Exit                                  |\n");
        printf("-----------------------------------------------------\n");
        printf("Enter your choice: ");

        if (fgets(buffer, sizeof(buffer), stdin) != NULL) {
            if (sscanf(buffer, "%d", &choice) != 1) {
                printf("Invalid choice. Please enter a number.\n");
                continue; 
            }

            switch (choice) {
                case 1:
                    printf("Directing to Hospital Administrator...\n");
                    HospitalAdministratorCheck();
                    break;
                case 2:
                    printf("Directing to Patient...\n");
                    PatientCheck();
                    break;
                case 3:
                    printf("Directing to Doctor...\n");
                    DoctorCheck();
                    break;
                case 4:
                    printf("Directing to Staff Nurse...\n");
                    NurseCheck();
                    break;
                case 5:
                    printf("Exiting Program...\n");
                    exit(0);
                default:
                    printf("Invalid choice. Try again.\n");
            }
        } else {
            printf("Input error. Please try again.\n");
        }

        
        while (getchar() != '\n');
        
    } while (choice != 5);

    return 0;
}